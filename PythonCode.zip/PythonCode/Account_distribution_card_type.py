import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data=pd.read_csv("C:\\Users\\yasir\\Downloads\\Internship\\End-To-End-Data-Analytics-Project_Banking-main\\cleaned files\\Cardcleaned.csv")
print(data.head(10))
df_accounts = pd.DataFrame(data)

# Count the number of accounts per card type
card_type_counts = df_accounts['card_type'].value_counts()

# Define colors for the pie chart
colors = ['#ffd700', '#c0c0c0', '#b9f2ff']

# Create the pie chart
plt.figure(figsize=(10, 7))
wedges, texts, autotexts = plt.pie(card_type_counts, labels=card_type_counts.index, autopct='%1.1f%%', startangle=140, colors=colors, wedgeprops=dict(width=0.3))

# Customize the font size and color of the labels and percentages
for autotext in autotexts:
    autotext.set_fontsize(14)
    autotext.set_color('green')
    autotext.set_weight('bold')

# Add a legend with more detailed information
plt.legend(wedges, [f'{card_type}: {count} accounts' for card_type, count in zip(card_type_counts.index, card_type_counts)], loc='upper right', fontsize=12, bbox_to_anchor=(1.3, 1))

# Add a title with a larger font size and bold style
plt.title('Account Distribution Based on Card Type', fontsize=16, fontweight='bold')

# Show the pie chart
plt.show()