import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data=pd.read_csv("C:\\Users\\yasir\\Downloads\\Internship\\End-To-End-Data-Analytics-Project_Banking-main\\cleaned files\\tranx.csv")

#print(data.head(10))
df_accounts = pd.DataFrame(data)

# Filter the dataset for the years 2016, 2018, and 2020
filtered_df = df_accounts[df_accounts['year'].isin([2016, 2018, 2020])]

# Group by year and bank name to count unique account holders
account_holders_by_year = filtered_df.groupby(['year', 'bank'])['account_id'].nunique().reset_index()

# Pivot table to reformat data for line chart
pivot_table = account_holders_by_year.pivot(index='year', columns='bank', values='account_id').fillna(0)

# Check if values are small, avoid converting to thousands if they are small
if pivot_table.values.max() > 1000:
    pivot_table = pivot_table / 1000
    y_label = 'Number of Account Holders (in thousands)'
    y_formatter = lambda x, loc: f'{int(x)}k'
else:
    y_label = 'Number of Account Holders'
    y_formatter = lambda x, loc: f'{int(x)}'

# Plotting the line chart
plt.figure(figsize=(10, 7))
for bank_name in pivot_table.columns:
    plt.plot(pivot_table.index, pivot_table[bank_name], marker='o', label=bank_name)

# Add labels and title
plt.title('Number of Account Holders in Different Banks (Years: 2016, 2018, 2020)', fontsize=16, fontweight='bold')
plt.xlabel('Year', fontsize=14)
plt.ylabel(y_label, fontsize=14)
plt.xticks(pivot_table.index, fontsize=12)
plt.yticks(fontsize=12)
plt.legend(fontsize=12)

# Format y-axis labels
plt.gca().get_yaxis().set_major_formatter(plt.FuncFormatter(y_formatter))

# Show the line chart
plt.grid(True)
plt.tight_layout()
plt.show()