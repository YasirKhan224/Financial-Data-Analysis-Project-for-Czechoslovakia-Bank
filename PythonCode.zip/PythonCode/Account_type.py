import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data=pd.read_csv("C:\\Users\\yasir\\Downloads\\Internship\\End-To-End-Data-Analytics-Project_Banking-main\\cleaned files\\accountcleaned.csv")
print(data.head(10))
df_accounts = pd.DataFrame(data)

# Count the number of accounts per account type
account_type_counts = df_accounts['Account_type'].value_counts()

# Calculate percentages
total_accounts = len(df_accounts)
account_type_percents = (account_type_counts / total_accounts) * 100

# Define colors for the pie chart
colors = ['#66b3ff', '#99ff99', '#ff9999']

# Create the pie chart
plt.figure(figsize=(10, 7))
wedges, texts, autotexts = plt.pie(account_type_counts, labels=account_type_counts.index, autopct='%1.1f%%', startangle=140, colors=colors, wedgeprops=dict(width=0.3))

# Customize the font size and color of the labels and percentages
for autotext in autotexts:
    autotext.set_fontsize(14)
    autotext.set_color('Red')
    autotext.set_weight('bold')

# Prepare legend labels
legend_labels = [f'{account_type}: {account_type_percents[account_type]:.1f}%' for account_type in account_type_counts.index]

# Add a legend with more detailed information
plt.legend(wedges, legend_labels, loc='upper right', fontsize=12, bbox_to_anchor=(1.3, 1))

# Add a title with a larger font size and bold style
plt.title('Account Distribution Based on Account Type', fontsize=16, fontweight='bold')

# Show the pie chart
plt.show()