import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data=pd.read_csv("C:\\Users\\yasir\\Downloads\\Internship\\End-To-End-Data-Analytics-Project_Banking-main\\cleaned files\\client.csv")
print(data.head(10))
df_accounts = pd.DataFrame(data)


# Ensure gender values are consistent (uppercase)
df_accounts['Sex'] = df_accounts['Sex'].str.upper()

# Count the number of accounts per gender
gender_counts = df_accounts['Sex'].value_counts()

# Define colors for the pie chart
colors = ['#66b3ff', '#ff9999']

# Create the pie chart
plt.figure(figsize=(10, 7))
plt.pie(gender_counts, labels=gender_counts.index, autopct='%1.1f%%', startangle=140, colors=['#66b3ff', '#ff9999'])



# Add a title with a larger font size and bold style
plt.title('Gender-wise Account Holders', fontsize=16, fontweight='bold')

# Show the pie chart
plt.show()