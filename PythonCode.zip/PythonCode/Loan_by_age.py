import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data=pd.read_csv("C:\\Users\\yasir\\Downloads\\Internship\\End-To-End-Data-Analytics-Project_Banking-main\\cleaned files\\dataset cleaned\\Loancleaned.csv")
data=pd.read_csv("C:\\Users\\yasir\\Downloads\\Internship\\End-To-End-Data-Analytics-Project_Banking-main\\cleaned files\\dataset cleaned\\Clientclear.csv")
print(data.head(10))
df_loans = pd.DataFrame(data)

# Aggregate the loan amounts by status
loan_status_sums = df_loans.groupby('age')['amount'].sum()

# Define colors for the bar chart
colors = ['#4CAF50', '#FFC107', '#F44336']

# Create the bar chart
plt.figure(figsize=(10, 7))
bars = plt.bar(loan_status_sums.index, status_sums.values, color=colors)

# Add labels to the bars
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2.0, yval, f'{yval:.2f}', va='bottom', ha='center', fontsize=12, color='black', fontweight='bold')

# Add a title and labels
plt.title('Total Loan Amount by Status', fontsize=16, fontweight='bold')
plt.xlabel('Loan Status', fontsize=14)
plt.ylabel('Total Loan Amount', fontsize=14)

# Show the bar chart
plt.show()