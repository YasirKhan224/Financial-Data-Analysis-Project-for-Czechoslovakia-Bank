import pandas as pd
import matplotlib.pyplot as plt

# Load the data from the CSV file
data=pd.read_csv("C:\\Users\\yasir\\Downloads\\Internship\\End-To-End-Data-Analytics-Project_Banking-main\\cleaned files\\loanportfolio.csv")

# Display the first few rows of the dataframe to understand its structure
print(data.head())

# Assuming the dataframe has 'status', 'amount' columns
# Calculate the number of loans and average loan amount by status
status_summary = data.groupby('status').agg(num_loans=('amount', 'size'), avg_loan_amount=('amount', 'mean')).reset_index()

# Create the bar chart
fig, ax1 = plt.subplots(figsize=(12, 6))

# Plot number of loans as bar chart
ax1.bar(status_summary['status'], status_summary['num_loans'], color='skyblue', label='Number of Loans')

# Create another y-axis for the average loan amount
ax2 = ax1.twinx()
ax2.plot(status_summary['status'], status_summary['avg_loan_amount'], color='green', marker='o', label='Average Loan Amount')

# Set the labels and title
ax1.set_xlabel('Loan Status')
ax1.set_ylabel('Number of Loans')
ax2.set_ylabel('Average Loan Amount ($)')
plt.title('Number of Loans and Average Loan Amount by Status')

# Combine the legends
lines, labels = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines + lines2, labels + labels2, loc='upper left')

# Display the plot
plt.show()
