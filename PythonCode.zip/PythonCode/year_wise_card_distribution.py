import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data=pd.read_csv("C:\\Users\\yasir\\Downloads\\Internship\\End-To-End-Data-Analytics-Project_Banking-main\\cleaned files\\Cardcleaned.csv")
print(data.head(10))
df_cards = pd.DataFrame(data)

# Group by year and card type to count occurrences
card_distribution_by_year = df_cards.groupby(['year', 'card_type'])['card_id'].count().reset_index()

# Pivot table to reformat data for line chart
pivot_table = card_distribution_by_year.pivot(index='year', columns='card_type', values='card_id').fillna(0)

# Plotting the line chart
plt.figure(figsize=(10, 7))
for card_type in pivot_table.columns:
    plt.plot(pivot_table.index, pivot_table[card_type], marker='o', label=card_type)
    for i in range(len(pivot_table)):
        plt.text(pivot_table.index[i], pivot_table[card_type].iloc[i], str(int(pivot_table[card_type].iloc[i])), fontsize=10, ha='center', va='bottom')

# Add labels and title
plt.title('Year-wise Card Distribution', fontsize=16, fontweight='bold')
plt.xlabel('Year', fontsize=14)
plt.ylabel('Number of Cards', fontsize=14)
plt.xticks(pivot_table.index, fontsize=12)
plt.yticks(fontsize=12)
plt.legend(title='Card Type', fontsize=12)

# Show the line chart
plt.grid(True)
plt.tight_layout()
plt.show()