import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data=pd.read_csv("C:\\Users\\yasir\\Downloads\\Internship\\End-To-End-Data-Analytics-Project_Banking-main\\cleaned files\\dataset cleaned\\Loancleaned.csv")
print(data.head(10))
df_cards = pd.DataFrame(data)

loan_by_year = data.groupby('year')['amount'].sum().reset_index()

# Convert loan amounts to thousands (K)
loan_by_year['loan_amount_k'] = loan_by_year['amount'] / 1000

# Plotting the line chart
plt.figure(figsize=(10, 6))
plt.plot(loan_by_year['year'], loan_by_year['loan_amount_k'], marker='o', color='yellow', linestyle='-', linewidth=2, markersize=8)

# Adding labels and title
plt.title('Total Loan Amount by Year', fontsize=16, fontweight='bold')
plt.xlabel('Year', fontsize=14)
plt.ylabel('Total Loan Amount (in K)', fontsize=14)
plt.xticks(loan_by_year['year'], rotation=45, fontsize=12)
plt.yticks(fontsize=12)

# Adding data labels to each point on the line
for i, (year, amount_k) in enumerate(zip(loan_by_year['year'], loan_by_year['loan_amount_k'])):
    plt.text(year, amount_k, f'{amount_k:.1f}K', ha='center', va='bottom', fontsize=10)

# Display the line chart
plt.grid(True)
plt.tight_layout()
plt.show()