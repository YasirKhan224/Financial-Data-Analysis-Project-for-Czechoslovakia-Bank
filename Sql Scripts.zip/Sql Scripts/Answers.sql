USE BANK;
-- 1.What is the demographic profile of the bank's clients and how does it vary across districts?
SELECT  C.DISTRICT_ID,D.DISTRICT_NAME,D.AVERAGE_SALARY,
ROUND(AVG(C.AGE),0) AS AVG_AGE,
SUM(CASE WHEN SEX = 'Male' THEN 1 ELSE 0 END) AS MALE_CLIENT ,
SUM(CASE WHEN SEX = 'Female' THEN 1 ELSE 0 END) AS FEMALE_CLIENT ,
ROUND((FEMALE_CLIENT/MALE_CLIENT)*100,2) AS MALE_FEMALE_RATIO_PERC,
COUNT(*)AS TOTAL_CLIENT
FROM CLIENT C
INNER JOIN DISTRICT D ON C.DISTRICT_ID = D.DISTRICT_CODE
GROUP BY 1,2,3
ORDER BY 1;

-- 2. How the banks have performed obver the years.Give their detailed analysis month wise?
SELECT
    YEAR(date) AS year,
    MONTH(date) AS month,
    SUM(CASE WHEN type = 'credit' THEN amount ELSE 0 END) AS total_deposits,
    SUM(CASE WHEN type = 'withdrawal' THEN amount ELSE 0 END) AS total_withdrawals,
    COUNT(*) AS num_transactions,
    AVG(amount) AS avg_transaction_amount
FROM
    transaction
GROUP BY
    YEAR(date),
    MONTH(date)
ORDER BY
    YEAR(date),
    MONTH(date);

-- What are the most common types of accounts and how do they differ in terms of usage and profitability

SELECT account_type, COUNT(*) AS num_accounts
FROM accountcleaned
GROUP BY account_type;

-- Which types of cards are most frequently used by the bank's clients and what is the overall profitability of the credit card business?

SELECT card_type, COUNT(*) AS num_users
FROM cardcleaned
GROUP BY card_type;

-- What is the bank’s loan portfolio and how does it vary across different purposes and client segments?
SELECT status, COUNT(*) AS num_loans, AVG(amount) AS avg_loan_amount
FROM loancleaned
GROUP BY status;
