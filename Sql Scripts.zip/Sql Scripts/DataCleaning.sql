CREATE DATABASE BANK;
USE BANK;
-- Account Cleaned data
SELECT 
    account_id,
    district_id,
    CASE 
        WHEN frequency = 'POPLATEK MESICNE' THEN 'Monthly issuance'
        WHEN frequency = 'POPLATEK TYDNE' THEN 'Weekly issuance'
        WHEN frequency = 'POPLATEK PO OBRATU' THEN 'Issuance after a transaction'
        ELSE frequency
    END AS frequency,
    DATE_FORMAT(DATE_ADD(STR_TO_DATE(date, '%y%m%d'), INTERVAL 24 YEAR), '%Y-%m-%d') AS date,
    Account_type
FROM 
    accountCleaned;
   

-- Card Cleaned data
SELECT 
    card_id,
    disp_id,
    CASE 
        WHEN type = 'junior' THEN 'Silver'
        WHEN type = 'Classic' THEN 'Gold'
        WHEN type = 'Gold' THEN 'Diamond'
        ELSE type
    END AS type,
    DATE_FORMAT(DATE_ADD(STR_TO_DATE(issued, '%y%m%d'), INTERVAL 23 YEAR), '%Y-%m-%d') AS issued
FROM 
    cardCleaned;

-- Client cleaned data
SELECT 
   client_id,district_id,

    DATE_FORMAT(DATE_ADD(STR_TO_DATE(birth_number, '%y%m%d'), INTERVAL 24 YEAR), '%Y-%m-%d') AS birth_date
FROM 
    clientCleaned;
    ALTER TABLE clientCleaned
ADD COLUMN sex INT; -- Assuming sex column should be INT (0 or 1)

-- Update the sex column based on birth_number
UPDATE clientCleaned
SET sex = CASE
    WHEN SUBSTRING(birth_number, 3, 1) IN ('0', '5', '6', '7', '8') THEN 0
    WHEN SUBSTRING(birth_number, 3, 1) IN ('1', '2', '3', '4') THEN 1
    ELSE NULL -- Handle other cases if necessary
    END;
   select * from client;
    
    -- district cleaned data
    -- Step 1: Change all column names as required
ALTER TABLE districtCleaned
RENAME COLUMN a15 TO No_committed_crime_2017,
RENAME COLUMN a16 TO No_committed_crime_2018;
select * from districtCleaned; 
-- Step 2: Delete attributes a12 and a13
ALTER TABLE districtCleaned
DROP COLUMN a12,
DROP COLUMN a13;

-- Loan data cleaned
SELECT 
   loan_id,account_id,amount,duration,payments,status,

    DATE_FORMAT(DATE_ADD(STR_TO_DATE(date, '%y%m%d'), INTERVAL 23 YEAR), '%Y-%m-%d') AS date
FROM 
    loanCleaned;
   -- step 2
   UPDATE loanCleaned
SET Status = CASE
    WHEN Status = 'A' THEN 'Contract Finished'
    WHEN Status = 'B' THEN 'Loan Not Paid'
    WHEN Status = 'C' THEN 'Running Contract'
    WHEN Status = 'D' THEN 'Client in debt'
    ELSE Status -- Handle any other values if needed
    END;
    select * from loanCleaned; 
    
    SELECT district_ID, AVG(age) AS avg_age, COUNT(*) AS num_clients
FROM client
GROUP BY district_id;

